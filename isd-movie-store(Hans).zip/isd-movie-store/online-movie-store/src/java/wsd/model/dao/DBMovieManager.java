/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package wsd.model.dao;
import java.sql.*;
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
import wsd.model.Movie;
/**
 *
 * @author Hans
 */
public class DBMovieManager {
    private final Statement st;
    
    public DBMovieManager(Connection conn) throws SQLException 
    {
        st = conn.createStatement();
    }
    
    public Movie findMovie(int MOVIE_ID) throws SQLException
    {
        //setup the select sql query string
        String searchQueryString = "select * from MOVIES where MOVIE_ID='" 
                + MOVIE_ID + "'";
        Movie MovieFromDB;
        //search the ResultSet for a movie using the parameters
        try ( //execute this query using the statement field
        //add the results to a ResultSet
                ResultSet rs = st.executeQuery(searchQueryString)) {
            //search the ResultSet for a movie using the parameters
            boolean hasMovieExist = rs.next();
            MovieFromDB = null;
            if(hasMovieExist)
            {
                
                int MovieID = Integer.parseInt(rs.getString("OrderID"));
                String Title = rs.getString("Title");
                int Duration = Integer.parseInt(rs.getString("Duration"));
                String Genra = rs.getString("Genra");
                double Price = Double.parseDouble(rs.getString("Price"));
                int Stock = Integer.getInteger("Stock");
                
                MovieFromDB = new Movie (MovieID, Title, Duration, Genra, Price, Stock);
            }
        }
        return MovieFromDB;
    }
    
    //SELECT * FROM APP.MOVIES FETCH FIRST 100 ROWS ONLY;
        public void showMovie(int MovieID, String Title,  int Year, String Genre, 
            double Price, int Stock) throws SQLException
        {
        //setup the select sql query string
        String showQueryString;
        showQueryString = "select * from APP.MOVIES FETCH FIRST 100 ROWS ONLY";
        
        boolean MovieShown = st.executeUpdate(showQueryString) > 0;
        
        if (MovieShown)
        {
            System.out.println("Movie has been shown.");
        }
        else
        {
            System.out.println("Your request is denied.");
        }
        
        }
    
        public void addMovie(int MovieID, String Title, int Duration, String Genre, 
            double Price, int Stock) throws SQLException
        {
        //setup the select sql query string
        String addQueryString = "insert into APP.MOVIES" 
                + "values ('" + MovieID + "', '" + Title + "', '" 
                + Duration + "', '" + Genre + "', '" + Price + "', '" + Stock + "')";
        
        boolean MovieCreated = st.executeUpdate(addQueryString) > 0;
        
        if (MovieCreated)
        {
            System.out.println("Movie has been added.");
        }
        else
        {
            System.out.println("Your addidtion is denied.");
        }
        
        }
        
        public void updateMovie(int MovieID, String Title, int Duration, String Genre, 
            double Price, int Stock) throws SQLException {
        
        String updateQueryString = "update APP.MOVIES" 
                + "set values ('" + MovieID + "', '" + Title + "', '" 
                + Duration + "', '" + Genre + "', '" + Price + "', '" + Stock + "')";
        
        boolean MovieUpdated = st.executeUpdate(updateQueryString) > 0;
        
        if (MovieUpdated)
        {
            System.out.println("Movie has been updated.");
        }
        else
        {
            System.out.println("Your updating is denied.");
        }
        
    }
}
